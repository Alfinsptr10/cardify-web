import Link from "next/link";
import type { PhotoboothLayout } from "@/lib/photobooth/layouts";

type LayoutCardProps = {
  layout: PhotoboothLayout;
};

export default function LayoutCard({ layout }: LayoutCardProps) {
  return (
    <Link
      href={`/photobooth/camera?layout=${layout.id}`}
      className="group block rounded-[2rem] border border-stone-200 bg-white/80 p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="mb-6 flex h-44 w-full flex-col justify-between rounded-[1.75rem] border border-stone-100 bg-stone-50 p-4 text-stone-600">
        <div className="grid h-full gap-2">
          <div className="grid grid-cols-2 gap-2 flex-1">
            <div className="rounded-xl bg-white border border-stone-200" />
            <div className="rounded-xl bg-white border border-stone-200" />
          </div>
          {layout.photos === 5 ? (
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-white border border-stone-200 col-span-1 row-span-2" />
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
            </div>
          ) : layout.photos === 6 ? (
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-white border border-stone-200" />
              <div className="rounded-xl bg-white border border-stone-200" />
            </div>
          )}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-stone-900">{layout.name}</h3>
        <p className="mt-2 text-sm text-stone-500">{layout.previewLabel}</p>
      </div>
    </Link>
  );
}
